// ===================================================================
// VICTIMS CORE UNPACKER ENGINE [VERSION 1.0.0]
// Architecture Engine written to optimize Luau Arrays & Stubs
// Powered by DRIFFIN Custom Optimization Architecture
// ===================================================================

document.addEventListener("DOMContentLoaded", () => {
    const unpackBtn = document.getElementById("unpackCoreBtn");
    const payloadInput = document.getElementById("payloadInput");
    const compilerSelect = document.getElementById("targetCompiler");
    const validateTokenBtn = document.getElementById("validateTokenBtn");

    // Simulated Ad-Token Status Handler (Huwag galawin para sa Monetag Integration)
    validateTokenBtn.addEventListener("click", () => {
        alert("[VICTIMS] Ad-Token Validation: Session active and secure.");
    });

    // Core Processing Handler
    unpackBtn.addEventListener("click", () => {
        let rawInput = payloadInput.value.trim();

        if (!rawInput) {
            alert("Pakilagay muna yung obfuscated payload sa terminal window.");
            return;
        }

        // Itago ang orihinal para sa processing sequence
        payloadInput.value = "-- [ VICTIMS CORE ]: INITIALIZING DECONSTRUCTION SEQUENCE... \n-- Processing buffer streams, please wait...";
        
        setTimeout(() => {
            try {
                let cleanResult = executeUnpackingCore(rawInput, compilerSelect.value);
                payloadInput.value = cleanResult;
            } catch (err) {
                payloadInput.value = `-- [ VICTIMS CRITICAL ERROR ]\n-- Failed to deconstruct payload cleanly.\n-- Error Details: ${err.message}`;
            }
        }, 600);
    });
});

function executeUnpackingCore(input, targetType) {
    let processingOutput = input;
    processingOutput = cleanTemplatePlaceholders(processingOutput);

    if (targetType === "luau_roblox") {
        processingOutput = deconstructStandardLuauObfuscation(processingOutput);
    } else if (targetType === "luau_bytecode") {
        processingOutput = processBytecodeVMLogic(processingOutput);
    }

    return processingOutput;
}

function cleanTemplatePlaceholders(source) {
    return source.replace(/\$\{[^}]+\}/g, '"[VICTIMS_RESTORED_PROPERTY]"');
}

function deconstructStandardLuauObfuscation(source) {
    let logHeader = `-- // ===================================================================\n`;
    logHeader += `-- // VICTIMS CORE UNPACKER [SUCCESSFULLY DECONSTRUCTED]\n`;
    logHeader += `-- // Target Environment: LUAU RECONSTRUCTED SOURCE\n`;
    logHeader += `-- // ===================================================================\n\n`;

    let activeSource = source;

    // Convert hex values (\\x41 -> A)
    activeSource = activeSource.replace(/\\x([0-9A-Fa-f]{2})/g, (match, hex) => {
        return String.fromCharCode(parseInt(hex, 16));
    });

    // Convert decimal byte escape (\\065 -> A)
    activeSource = activeSource.replace(/\\([0-9]{3})/g, (match, dec) => {
        return String.fromCharCode(parseInt(dec, 10));
    });

    // Extract structure kung template framework lang ang pumasok
    if (activeSource.includes("unpackObfuscatedRobloxStudioScript")) {
        let extractMatch = activeSource.match(/memory_block_pointer\s*=\s*"([^"]+)"/);
        if (extractMatch && extractMatch[1]) {
            return logHeader + `-- Exposed Payload Pointer:\nlocal target_data = "${extractMatch[1]}"\n\n-- [END OF SCAN]`;
        }
    }

    activeSource = activeSource.replace(/\n\s*\n/g, '\n');
    return logHeader + activeSource + `

=== [ END OF SCAN ] ===`;
}

function processBytecodeVMLogic(source) {
    let vmHeader = `-- // ===================================================================\n`;
    vmHeader += `-- // VICTIMS CORE UNPACKER [BYTECODE SCAN TERMINATED]\n`;
    vmHeader += `-- // ===================================================================\n\n`;
    vmHeader += `print("[-] Paalala: Walang readable text. Kung ito ay puro simbolo o numero, 100% encrypted bytecode ito.")\n\n`;
    
    if (source.match(/(?:while\s+.*do|if\s+.*==.*then)/gi)) {
        vmHeader += `-- [ANALYSIS]: Custom Virtual Machine Loop Found.\n`;
        vmHeader += `-- Extraction framework is reading Opcode Constants blocks...\n\n`;
        vmHeader += source;
    } else {
        vmHeader += `-- [ANALYSIS]: Unknown bytecode layout. Raw string returned.\n\n` + source;
    }

    vmHeader += `\n\nprint("=== [ END OF SCAN ] ===\\n")\nEOF`;
    return vmHeader;
}
